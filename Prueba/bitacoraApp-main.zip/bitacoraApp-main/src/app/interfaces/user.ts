export interface User {
  id: number;
  nombre: string;
  email: string;
  // Otros campos relevantes del usuario
}
