export interface IResponseRegister {
    status: string,
}