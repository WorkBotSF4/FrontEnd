export interface registerCredentials {
    nombre?:String,
    apellido?:String,
    usuario?:String,
    contrasena?:String,
    idTipoUsuario?:Number
}