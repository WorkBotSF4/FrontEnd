export interface IAgendaResponse {
    status: string,
}