export interface registerEquipoCredentials {
    tipoEquipo?:number,
    marca?:String

}