export interface IDataChek {
    idChek: number,
    estado: boolean
}
