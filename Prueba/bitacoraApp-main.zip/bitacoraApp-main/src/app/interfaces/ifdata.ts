export interface IFData {
    idUser: number,
    desc: string
}