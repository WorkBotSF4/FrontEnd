export interface IUserLogged {
    id: number,
    nombre: string,
    token: string
}