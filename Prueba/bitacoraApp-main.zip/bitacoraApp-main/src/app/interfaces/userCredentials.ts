export interface IUserCredentials {
    nombreUsuario: string,
    password: string
}