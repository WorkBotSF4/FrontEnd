export interface User {
    Name: string;
    lastName : String;
    user: string;
    password: string
}
