export interface IResponseEquipo {
    status: string,
}